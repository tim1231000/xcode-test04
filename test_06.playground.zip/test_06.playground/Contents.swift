import UIKit

func sayHello(m:String) {
    print(m)
}
sayHello(m: "I can code functions!")

func doAdd(firstNum a:Int, secondNum b:Int) {
    var sum = a + b
    print(sum)
}
doAdd(firstNum: 10, secondNum: 20)

func doAdd(a:Int, b:Int) -> Int {
    var sum = a + b
    return sum
}
doAdd(a: 10, b: 20)
print(doAdd(a: 10, b: 20))

func doSum(_ a:Int, _ b:Int) -> Int {
    var sum = a + b
    return sum
}
let result = doSum(10, 20)
print(result)
