import UIKit

var greeting:String = "Hello, playground"
print(greeting)

greeting = "I can write Swift!"
print(greeting)

let myInt:Int = 5
print(myInt)

var myDouble:Double = 0.5
print(myDouble)

var myBool:Bool = false
print(myBool)
