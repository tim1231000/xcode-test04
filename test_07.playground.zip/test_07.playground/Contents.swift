import UIKit

var a = 4
var b = 20
var c = 10

if a > b {
     //Some code in here
    print("Bang")
}
else if b > c {
    print("Shoot")
}
else {
    print("hello")
}
